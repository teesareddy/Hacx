import"./style-CNP0ENT6.js";const o=document.querySelector("form"),t=new URLSearchParams(window.location.search).get("state");o.action="/interaction/"+t;
