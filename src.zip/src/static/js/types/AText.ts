export type AText = {
  text: string,
  attribs: string,
}
