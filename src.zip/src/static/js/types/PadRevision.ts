export type PadRevision = {
  revNum: number;
  savedById: string;
  label: string;
  timestamp: number;
  id: string;
}
