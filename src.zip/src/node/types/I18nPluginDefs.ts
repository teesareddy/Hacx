export type I18nPluginDefs = {
    package: {
        path: string
    }
}