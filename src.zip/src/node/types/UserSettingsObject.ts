export type UserSettingsObject = {
    canCreate: boolean,
    readOnly: boolean,
    padAuthorizations: any
}
