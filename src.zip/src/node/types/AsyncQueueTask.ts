export type AsyncQueueTask = {
    srcFile: string,
    destFile: string,
    type: string
}