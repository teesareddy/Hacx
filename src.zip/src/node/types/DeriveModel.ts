export type DeriveModel = {
    digest: string,
    secret: string,
    salt: string,
    keyLen: number
}