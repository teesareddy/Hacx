export type SocketModule = {
    setSocketIO: (io: any) => void;
}
