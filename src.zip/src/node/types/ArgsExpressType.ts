import {Express} from "express";

export type ArgsExpressType = {
    app:Express,
    io: any,
    server:any
}
